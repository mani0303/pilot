package com.test.core;


import com.test.support.Identifier;
import com.test.support.Settings;

public class Test_Controller {
	Identifier identifier = Identifier.getInstance();
	Settings setting = Settings.getInstance();
	public static void main(String args[]){
		Test_Controller tc= new Test_Controller();
		tc.controller();
	}
	
	public void controller(){
		/*ExcelHelper eh = new ExcelHelper();
		try {
			eh.readTestRunner("TestRunner",setting.getTestRunner());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}
}
