package com.test.support;

import java.io.File;

public class Settings {
	private static Settings settings;
	private String projectPath;
	private String configurationProp;
	private String testRunner;
	private String elementPropertiesDir;
	private String driverEXEDir;
	private Settings(){};
	public static Settings getInstance(){
		if(settings==null){
			settings= new Settings();
		}
		return settings;
	}
	public void setProjectPath(){
		String projectPath = new File(System.getProperty("user.dir")).getAbsolutePath();
		this.projectPath=projectPath;
	}
	public String getProjectPath() {
		if(projectPath==null){
			setProjectPath();
		}
		return projectPath;
	}

	public String getConfigurationProp() {
		if(configurationProp==null){
			setConfigurationProp();
		}
		return configurationProp;
	}
	public void setConfigurationProp() {
		this.configurationProp = getProjectPath()+System.getProperty("file.separator")+"resources"+System.getProperty("file.separator")+"configuration.properties";
	}
	
	public String getTestRunner() {
		if(testRunner==null){
			setTestRunner();
		}
		return testRunner;
	}
	public void setTestRunner() {
		this.testRunner = getProjectPath()+System.getProperty("file.separator")+"resources"+System.getProperty("file.separator")+"Test_Runner.xlsx";
	}
	
	public String getElementPropertiesDir() {
		if(elementPropertiesDir==null){
			setElementPropertiesDir();
		}
		return elementPropertiesDir;
	}
	public void setElementPropertiesDir() {
		this.elementPropertiesDir = getProjectPath()+System.getProperty("file.separator")+"resources"+System.getProperty("file.separator")+"element-properties"+System.getProperty("file.separator");
	}
	
	public String getDriverEXEDir() {
		if(driverEXEDir==null){
			setDriverEXEDir();
		}
		return driverEXEDir;
	}
	public void setDriverEXEDir() {
		this.driverEXEDir = getProjectPath()+System.getProperty("file.separator")+"resources"+System.getProperty("file.separator")+"driver-exe"+System.getProperty("file.separator");
	}
}
