package com.test.support;

public enum Driver {
	FIREFOX("firefox"),GOOGLE_CHROME("chrome"),IE("ie"),MICROSOFT_EDGE("edge");
	Driver(String driver){
		
	}
}
