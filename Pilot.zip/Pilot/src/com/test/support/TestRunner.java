package com.test.support;

import java.util.HashMap;

public class TestRunner {
	HashMap<String,HashMap<String,String>> testRunnerInfo = new HashMap<String,HashMap<String,String>>();
	public void getTestRunnerInfo(){
		HashMap<String,String> td = new HashMap<String,String>();
		td.put("Test_Type", "Functional");
		testRunnerInfo.put("1001",td);
		
		
		

	}
	
	
}
